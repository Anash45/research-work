<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Task Calendar</title>
        
    </head>

    <body>
        <div id="calendar"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/6.1.11/index.global.min.js"
            integrity="sha512-WPqMaM2rVif8hal2KZZSvINefPKQa8et3Q9GOK02jzNL51nt48n+d3RYeBCfU/pfYpb62BeeDf/kybRY4SJyyw=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function () {
                // Initialize FullCalendar
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth', // Display month view by default
                    events: [], // Initialize with no events
                    eventClick: function (info) {
                        // Display task details when clicked
                        // console.log('Task ID: ' + info.event.id + '\nTask Title: ' + info.event.title + '\nBoard ID: ' + info.event.extendedProps.board_id);
                        window.location = "tasks.php?board_id=" + info.event.extendedProps.board_id + "&task_id=" + info.event.id;
                    }
                });

                // Fetch tasks from server and render on the calendar
                // You can fetch tasks using AJAX and then dynamically add them to the calendar
                // Example:
                $.ajax({
                    url: 'fetchTasks.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function (response) {
                        calendar.addEventSource(response); // Add tasks to the calendar
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                        alert('Error fetching tasks.');
                    }
                });

                // Render the calendar
                calendar.render();
            });


        </script>
    </body>

</html>