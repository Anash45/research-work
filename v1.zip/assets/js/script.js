(function () {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
        })
})()

function populateEditTask(title, description, deadline, priority, status, task_id) {
    console.log(title, description, deadline, priority, status, task_id);
    $('#editTaskModal #ed_taskTitle').val(title);
    $('#editTaskModal #ed_taskDescription').html(description);
    $('#editTaskModal #ed_deadlineDate').val(deadline);
    $('#editTaskModal #ed_moodPerception').val(priority);
    $('#editTaskModal #ed_taskStatus').val(status);
    $('#editTaskModal #ed_task_id').val(task_id);
    $('#editTaskModal').modal('show');
}

$(document).ready(function () {
    // Make tasks draggable
    $('.task').draggable({
        helper: 'clone',
        cursor: 'move',
        zIndex: 1000,
        opacity: 0.7
    });

    // Make tasks div droppable
    $('.tasks').droppable({
        accept: '.task',
        drop: function (event, ui) {
            var droppedTask = ui.draggable;
            droppedTask.detach().css({ top: 0, left: 0 }).appendTo($(this));
            var taskId = droppedTask.attr('data-id');
            var status = $(this).attr('data-status');
            console.log('Task ID: ' + taskId + ', Status: ' + status);
            // Make AJAX call to updateTaskStatus.php
            $.ajax({
                url: 'updateTaskStatus.php',
                type: 'POST',
                data: { taskId: taskId, status: status },
                success: function (response) {
                    console.log(response);
                    // Add your success handling logic here
                    updateCounts();
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Add your error handling logic here
                }
            });
        }
    });
});

function updateCounts() {
    $('.tasks').each(function () {
        let tasksCount = $(this).find('.task').length;
        console.log(tasksCount);
        $(this).siblings('div').find('.task-counter').text(`(${tasksCount})`);
    })
}

updateCounts();

$(document).ready(function () {
    // Toggle sorting order
    var ascending = true;

    // Sort tasks based on data-priority attribute
    function sortTasks(elm) {
        var $tasksContainer = elm.closest('.task-info').siblings('.tasks');
        var $tasks = $tasksContainer.children('.task');
        $tasks.sort(function (a, b) {
            var priorityA = parseInt($(a).attr('data-priority'));
            var priorityB = parseInt($(b).attr('data-priority'));
            return ascending ? priorityA - priorityB : priorityB - priorityA;
        });
        $tasks.detach().appendTo($tasksContainer);
    }

    // Handle sort button click
    $('.sortButton').click(function () {
        let elm = $(this);
        ascending = !ascending; // Toggle sorting order
        sortTasks(elm);
    });
});
