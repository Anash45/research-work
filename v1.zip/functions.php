<?php
// Function to check if user is logged in
function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

function getAllBoards($user_id)
{
    global $conn;
    // Initialize an empty array to store the boards
    $boards = array();

    // Prepare and execute query to fetch boards of the user
    $query = "SELECT * FROM boards WHERE user_id = ? ORDER BY board_order";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Loop through the result set and store each board in the array
    while ($row = $result->fetch_assoc()) {
        $boards[] = $row;
    }

    // Return the array of boards
    return $boards;
}

function getBoardById($board_id)
{
    global $conn;
    // Initialize an empty array to store the boards
    $boards = array();

    // Prepare and execute query to fetch boards of the user
    $query = "SELECT * FROM boards WHERE board_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $board_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $board = $result->fetch_assoc();
    // Return the array of boards
    return $board;
}